
var vagaSwitch = false;
var vagaSwitch2 = false;
var vagaSwitch3 = false;
var vagaSwitch4 = false;
var vagas = 0;
var disponiveis = 4;
var dinheiro = 0;
var botao = 



function reservarVagas() {
    alert('Numero de vagas disponiveis: ' + disponiveis)
    alert('Numero de entradas no Estacionamento: ' + dinheiro)
    alert('Valor ganho: R$ ' + dinheiro * 10)
}